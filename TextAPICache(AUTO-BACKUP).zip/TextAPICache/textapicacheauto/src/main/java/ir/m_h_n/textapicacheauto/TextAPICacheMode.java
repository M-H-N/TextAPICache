package ir.m_h_n.textapicacheauto;

public enum TextAPICacheMode {
    NORMAL_MODE,
    MOST_OFFLINE_MODE
}
