package ir.m_h_n.textapicacheauto.exceptions;

public class RequestUnsuccessfulException extends Exception {
}
